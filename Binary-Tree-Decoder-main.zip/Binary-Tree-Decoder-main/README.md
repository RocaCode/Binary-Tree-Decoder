# Binary-Tree-Decoder
A program to encode and decode message from an imported text.
